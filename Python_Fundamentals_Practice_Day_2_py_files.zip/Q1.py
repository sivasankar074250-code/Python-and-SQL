N = int(input("N = "))
number = int(input("Number = "))

print("Primes:", end=" ")
for i in range(2, N + 1):
    prime = True
    for j in range(2, i):
        if i % j == 0:
            prime = False
            break
    if prime:
        print(i, end=" ")

print()
factorial = 1
for i in range(1, N + 1):
    factorial *= i
print("Factorial:", factorial)

print("Fibonacci:", end=" ")
a, b = 0, 1
for i in range(N):
    print(a, end=" ")
    a, b = b, a + b
print()

temp = number
digit_sum = 0
reverse = 0

while temp > 0:
    digit = temp % 10
    digit_sum += digit
    reverse = reverse * 10 + digit
    temp //= 10

print("Digit Sum:", digit_sum)
print("Reverse:", reverse)
