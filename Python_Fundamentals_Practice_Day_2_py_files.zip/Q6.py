entry = input("Entry Time: ")
exit_time = input("Exit Time: ")

entry_hour, entry_minute = map(int, entry.split(":"))
exit_hour, exit_minute = map(int, exit_time.split(":"))

entry_total = entry_hour * 60 + entry_minute
exit_total = exit_hour * 60 + exit_minute

if exit_total < entry_total:
    exit_total += 24 * 60

duration = exit_total - entry_total
hours = duration // 60
minutes = duration % 60

billable_hours = (duration + 59) // 60

if billable_hours == 0:
    fee = 0
else:
    fee = 30 + (billable_hours - 1) * 20

print(f"Parking Duration : {hours} hours {minutes} minutes")
print(f"Billable Hours : {billable_hours}")
print(f"Parking Fee : ₹{fee}")
