x = int(input())

if x < 0:
    print(False)
else:
    original = x
    reverse = 0

    while x > 0:
        digit = x % 10
        reverse = reverse * 10 + digit
        x //= 10

    print(original == reverse)
