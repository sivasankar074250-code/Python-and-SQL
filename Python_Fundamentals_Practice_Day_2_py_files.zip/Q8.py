x = int(input())

sign = -1 if x < 0 else 1
x = abs(x)

reverse = 0

while x > 0:
    digit = x % 10
    reverse = reverse * 10 + digit
    x //= 10

print(sign * reverse)
