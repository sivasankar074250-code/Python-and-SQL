amount = int(input("Withdrawal Amount: "))

if amount % 10 != 0:
    print("Transaction rejected: Amount must be a multiple of 10.")
elif amount > 20000:
    print("Transaction rejected: Withdrawal limit is ₹20000.")
else:
    remaining = amount

    notes_500 = remaining // 500
    remaining %= 500

    notes_200 = remaining // 200
    remaining %= 200

    notes_100 = remaining // 100
    remaining %= 100

    notes_50 = remaining // 50
    remaining %= 50

    notes_10 = remaining // 10

    total_notes = notes_500 + notes_200 + notes_100 + notes_50 + notes_10

    print(f"₹500 notes : {notes_500}")
    print(f"₹200 notes : {notes_200}")
    print(f"₹100 notes : {notes_100}")
    print(f"₹50 notes : {notes_50}")
    print(f"₹10 notes : {notes_10}")
    print(f"Total Notes : {total_notes}")
    print(f"Amount : ₹{amount}")
