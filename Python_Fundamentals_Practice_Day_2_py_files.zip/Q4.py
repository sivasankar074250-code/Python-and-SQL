customer = input("Customer: ")
units = int(input("Units: "))

if units <= 100:
    amount = units * 3
elif units <= 200:
    amount = 100 * 3 + (units - 100) * 5
else:
    amount = 100 * 3 + 100 * 5 + (units - 200) * 7

print(f"Customer : {customer}")
print(f"Units : {units}")
print(f"Amount : ₹{amount:.2f}")
