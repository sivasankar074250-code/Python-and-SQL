text = input("Enter string: ")

reverse_loop = ""
for char in text:
    reverse_loop = char + reverse_loop

reverse_slice = text[::-1]

cleaned = ""
for char in text:
    if char != " ":
        cleaned += char.lower()

reverse_cleaned = ""
for char in cleaned:
    reverse_cleaned = char + reverse_cleaned

print("Loop Reverse:", reverse_loop)
print("Slice Reverse:", reverse_slice)
print("Palindrome:", cleaned == reverse_cleaned)

vowels = 0
consonants = 0
digits = 0

for char in text:
    if char.isdigit():
        digits += 1
    elif char.isalpha():
        if char.lower() in "aeiou":
            vowels += 1
        else:
            consonants += 1

print("Vowels:", vowels)
print("Consonants:", consonants)
print("Digits:", digits)
