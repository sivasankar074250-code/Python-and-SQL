n = int(input("Number of Deliveries: "))

total_distance = 0
total_earnings = 0

distances = list(map(float, input("Distances: ").split()))

for distance in distances:
    total_distance += distance

    if distance <= 5:
        earnings = 40
    else:
        earnings = 40 + (distance - 5) * 8

    total_earnings += earnings

average_distance = total_distance / n

print(f"Total Distance : {total_distance:.2f} km")
print(f"Total Earnings : ₹{total_earnings:.2f}")
print(f"Average Distance : {average_distance:.2f} km")
